import matplotlib.pyplot as plt
import numpy as np

# 读取数据，假设文件名为 "data.txt"
# 文件内容: 第一列为z, 第二列为T, 第三列为O2
data = np.loadtxt('/home/xsj/lk/1120-1126/cjrO2NH3/10_23/10_23_axisSample_data_3.csv', delimiter=',', skiprows=1)

# 提取数据列
z = data[:, 0]  # z距离
T = data[:, 1]  # 温度T
O2 = data[:, 2]  # 氧气质量分数O2

# 创建图形
fig, ax1 = plt.subplots()

# 绘制温度T，左侧纵坐标轴
ax1.set_xlabel('z ')
ax1.set_ylabel('Temperature', color='tab:red')
ax1.plot(z, T, color='tab:red', label='Temperature')
ax1.tick_params(axis='y', labelcolor='tab:red')

# 创建右侧纵坐标轴（氧气质量分数O2）
ax2 = ax1.twinx()  # 创建共享x轴的第二个坐标轴
ax2.set_ylabel('O2MassFraction', color='tab:blue')
ax2.plot(z, O2, color='tab:blue', label='O2MassFraction')
ax2.tick_params(axis='y', labelcolor='tab:blue')

# 设置标题
plt.title('Temperature and O2MassFraction of Axis')

# 保存图形
plt.savefig('T_O2-z.png')  # 保存为 T_O2-z.png 文件

# # 显示图形
# plt.show()
