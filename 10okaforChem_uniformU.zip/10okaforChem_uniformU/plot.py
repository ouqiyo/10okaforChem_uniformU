import pandas as pd
import matplotlib.pyplot as plt
import os

# 获取当前路径的最后一级目录名称
current_dir = os.path.basename(os.getcwd())

# 读取数据文件（修改路径和文件名）
data_file = 'postProcessing/sample/3/axisSample_T_O2_OH_CO2_H2O_NH3_p.xy'
data = pd.read_csv(data_file, delim_whitespace=True, header=None, names=['z', 'T', 'O2', 'OH', 'CO2', 'H2O','NH3','p'])

# 逐一读取其他字段（如T、O2、OH等）并加入到DataFrame
data['U'] = pd.read_csv('postProcessing/sample/3/axisSample_U.xy', delim_whitespace=True, header=None)[3]

# 生成保存文件名
csv_filename = f"{current_dir}_axisSample_data_3.csv"
image_filename = f"{current_dir}_result_3.png"

# 保存为 CSV 文件
data.to_csv(csv_filename, index=False)

# 生成所需的图表
fig, axs = plt.subplots(4, 2, figsize=(12, 18))

# 添加图像标题
fig.suptitle(f"{current_dir}", fontsize=16, y=0.95)

# U(z)-z
axs[0, 0].plot(data['z'], data['U'])
axs[0, 0].set_title('U(z) - z')
axs[0, 0].set_xlabel('z')
axs[0, 0].set_ylabel('U(z)')

# T(z)-z
axs[0, 1].plot(data['z'], data['T'])
axs[0, 1].set_title('T(z) - z')
axs[0, 1].set_xlabel('z')
axs[0, 1].set_ylabel('T(z)')

# O2(z)-z
axs[1, 0].plot(data['z'], data['O2'])
axs[1, 0].set_title('O2(z) - z')
axs[1, 0].set_xlabel('z')
axs[1, 0].set_ylabel('O2(z)')

# OH(z)-z
axs[1, 1].plot(data['z'], data['OH'])
axs[1, 1].set_title('OH(z) - z')
axs[1, 1].set_xlabel('z')
axs[1, 1].set_ylabel('OH(z)')

# CO2(z)-z
axs[2, 0].plot(data['z'], data['CO2'])
axs[2, 0].set_title('CO2(z) - z')
axs[2, 0].set_xlabel('z')
axs[2, 0].set_ylabel('CO2(z)')

# H2O(z)-z
axs[2, 1].plot(data['z'], data['H2O'])
axs[2, 1].set_title('H2O(z) - z')
axs[2, 1].set_xlabel('z')
axs[2, 1].set_ylabel('H2O(z)')

# p(z)-z
axs[3, 0].plot(data['z'], data['p'])
axs[3, 0].set_title('p(z) - z')
axs[3, 0].set_xlabel('z')
axs[3, 0].set_ylabel('p(z)')

# p(z)-z
axs[3, 1].plot(data['z'], data['NH3'])
axs[3, 1].set_title('NH3(z) - z')
axs[3, 1].set_xlabel('z')
axs[3, 1].set_ylabel('NH3(z)')

# 调整布局和底部标题
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
# fig.text(0.5, 3, f"Directory: {current_dir}", ha='center', fontsize=12)

# 保存图像
plt.savefig(image_filename)
